-- Crear base de datos y tabla de ejemplo para entrenamiento
CREATE DATABASE IF NOT EXISTS nn_db;
USE nn_db;

DROP TABLE IF EXISTS training_data;
CREATE TABLE training_data (
  id INT AUTO_INCREMENT PRIMARY KEY,
  x1 DOUBLE NOT NULL,
  x2 DOUBLE NOT NULL,
  x3 DOUBLE NOT NULL,
  x4 DOUBLE NOT NULL,
  label DOUBLE NOT NULL
);

-- Ejemplos simples (puedes reemplazarlos por tu dataset):
INSERT INTO training_data (x1,x2,x3,x4,label) VALUES
(0.1, 0.2, 0.3, 0.4, 0),
(0.9, 0.8, 0.7, 0.6, 1),
(0.2, 0.1, 0.4, 0.3, 0),
(0.8, 0.9, 0.6, 0.7, 1),
(0.15,0.25,0.35,0.45,0);
