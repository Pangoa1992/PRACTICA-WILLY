package com.nn;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/*
 * Lee datos de la tabla 'training_data' con columnas: id, x1, x2, x3, x4, label
 * Devuelve pares (inputs[], label)
 */
public class DataLoader {

    public static class Sample {
        public double[] x;
        public double y; // etiqueta (asumimos problema de regresión o binaria)
        public Sample(double[] x, double y) { this.x = x; this.y = y; }
    }

    public static List<Sample> loadAll() {
        List<Sample> list = new ArrayList<>();
        String sql = "SELECT x1, x2, x3, x4, label FROM training_data ORDER BY id";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                double[] x = new double[4];
                for (int i = 0; i < 4; i++) x[i] = rs.getDouble(i+1);
                double y = rs.getDouble(5);
                list.add(new Sample(x, y));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }
}
