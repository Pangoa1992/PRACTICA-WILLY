package com.nn;

import java.util.List;

/*
 * Trainer simple: recorre las muestras por épocas y aplica SGD.
 */
public class Trainer {
    private NeuralNetwork nn;
    private double lr;

    public Trainer(NeuralNetwork nn, double lr) {
        this.nn = nn; this.lr = lr;
    }

    public void train(List<DataLoader.Sample> data, int epochs) {
        for (int e=1;e<=epochs;e++) {
            double sumErr = 0;
            int n = 0;
            for (DataLoader.Sample s : data) {
                sumErr += nn.trainSample(s.x, s.y, lr);
                n++;
            }
            System.out.printf("Epoch %d - MSE=%.6f\n", e, sumErr / Math.max(1, n));
        }
    }
}
