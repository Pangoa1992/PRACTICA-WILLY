package com.nn;

/*
 * Utilidades minimalistas de vectores/matrices (solo lo necesario)
 */
public class Matrix {

    public static double[] add(double[] a, double[] b) {
        double[] r = new double[a.length];
        for (int i=0;i<a.length;i++) r[i]=a[i]+b[i];
        return r;
    }

    public static double[] multiply(double[] a, double scalar) {
        double[] r = new double[a.length];
        for (int i=0;i<a.length;i++) r[i]=a[i]*scalar;
        return r;
    }

    public static double[][] random(int rows, int cols, double min, double max) {
        double[][] m = new double[rows][cols];
        for (int i=0;i<rows;i++) for (int j=0;j<cols;j++)
            m[i][j] = min + Math.random() * (max - min);
        return m;
    }

    public static double[] matVec(double[][] m, double[] v) {
        double[] r = new double[m.length];
        for (int i=0;i<m.length;i++) {
            double s = 0;
            for (int j=0;j<v.length;j++) s += m[i][j] * v[j];
            r[i] = s;
        }
        return r;
    }
}
