package com.nn;

/*
 * Red neuronal simple:  input -> hidden -> output (1 neurona salida)
 * Activación: sigmoid
 */
public class NeuralNetwork {
    private int inputSize;
    private int hiddenSize;
    private double[][] W1; // hiddenSize x inputSize
    private double[] b1;   // hiddenSize
    private double[] W2;   // hiddenSize -> single output (vector)
    private double b2;

    public NeuralNetwork(int inputSize, int hiddenSize) {
        this.inputSize = inputSize;
        this.hiddenSize = hiddenSize;
        W1 = Matrix.random(hiddenSize, inputSize, -0.5, 0.5);
        b1 = new double[hiddenSize];
        W2 = new double[hiddenSize];
        for (int i=0;i<hiddenSize;i++) W2[i] = (Math.random()-0.5);
        b2 = 0;
    }

    private double[] sigmoid(double[] v) {
        double[] r = new double[v.length];
        for (int i=0;i<v.length;i++) r[i] = 1.0/(1.0+Math.exp(-v[i]));
        return r;
    }

    private double sigmoid(double x) { return 1.0/(1.0+Math.exp(-x)); }

    public double forward(double[] x, double[] hiddenOut) {
        double[] z1 = Matrix.matVec(W1, x);
        for (int i=0;i<z1.length;i++) z1[i] += b1[i];
        double[] a1 = sigmoid(z1);
        if (hiddenOut != null) System.arraycopy(a1, 0, hiddenOut, 0, a1.length);
        double z2 = 0;
        for (int i=0;i<a1.length;i++) z2 += W2[i] * a1[i];
        z2 += b2;
        return sigmoid(z2);
    }

    // Train on single sample (SGD), returns squared error
    public double trainSample(double[] x, double y, double lr) {
        double[] a1 = new double[hiddenSize];
        double yhat = forward(x, a1);

        double error = yhat - y;
        double d_out = error * yhat * (1 - yhat); // derivative for output (sigmoid)

        // gradients for W2 and b2
        for (int i=0;i<hiddenSize;i++) {
            double gw = d_out * a1[i];
            W2[i] -= lr * gw;
        }
        b2 -= lr * d_out;

        // backprop into hidden
        for (int i=0;i<hiddenSize;i++) {
            double d_hidden = d_out * W2[i] * a1[i] * (1 - a1[i]);
            for (int j=0;j<inputSize;j++) {
                double gw = d_hidden * x[j];
                W1[i][j] -= lr * gw;
            }
            b1[i] -= lr * d_hidden;
        }

        return error * error;
    }
}
