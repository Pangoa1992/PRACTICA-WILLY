package com.nn;

import java.util.List;

/*
 * Ejecución de ejemplo:
 * 1) Crea la tabla y agrega filas con el script SQL.
 * 2) Ejecuta Main para cargar datos, entrenar y ver la salida.
 *
 * Se asume 4 entradas y etiqueta entre 0 y 1 (problema binario / regresión acotada).
 */
public class Main {
    public static void main(String[] args) {
        List<DataLoader.Sample> data = DataLoader.loadAll();
        if (data.isEmpty()) {
            System.out.println("No training data found. Please populate training_data table."); return;
        }
        NeuralNetwork nn = new NeuralNetwork(4, 6); // 4 entradas -> 6 neuronas ocultas -> 1 salida
        Trainer trainer = new Trainer(nn, 0.1);
        trainer.train(data, 100); // 100 épocas por defecto
        System.out.println("Training finished.");
    }
}
