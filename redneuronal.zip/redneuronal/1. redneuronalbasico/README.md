# SimpleNeuralNetJavaMySQL

Proyecto educativo básico en **Java** que implementa una red neuronal feedforward (MLP) desde cero
y carga datos de entrenamiento desde **MySQL**. Está pensado para NetBeans/Eclipse (proyecto simple).

## Qué incluye
- Implementación mínima de un perceptrón multicapa con una capa oculta (sigmoid).
- Entrenador con descenso por gradiente estocástico (SGD).
- Conexión a MySQL para leer la tabla `training_data` y almacenar/recuperar pesos opcionalmente.
- Código fuente en `src/com/nn/`.
- Script SQL `sql/create_mysql.sql` para crear la tabla de datos y ejemplo de filas.

## Requisitos
- JDK 8+
- MySQL server
- MySQL Connector/J (poner en librerías del proyecto)

## Cómo usar
1. Crear la base de datos y tabla MySQL usando `sql/create_mysql.sql`.
2. Editar `Database.java` y poner `DB_URL`, `DB_USER`, `DB_PASS` con tus credenciales MySQL.
3. Añadir `mysql-connector-java` a las librerías del proyecto.
4. Abrir el proyecto en NetBeans/Eclipse, compilar y ejecutar `com.nn.Main`.
5. `Main` cargará los datos de la tabla `training_data`, entrenará una red pequeña y mostrará el error por época.
6. Puedes ajustar hiperparámetros en `Trainer.java`.

## Notas
- Este proyecto es educativo: la red, escalado de datos y validación son mínimos.
- Puedes ampliar: más capas, funciones de activación, normalización, guardar pesos en BD, UI, etc.
